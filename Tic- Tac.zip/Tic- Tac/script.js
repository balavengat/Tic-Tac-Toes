 document.addEventListener('DOMContentLoaded', () => {
            const board = document.getElementById('board');
            const cells = Array.from({ length: 9 }, (_, index) => createCell(index));

            cells.forEach(cell => board.appendChild(cell));

            let currentPlayer = 'X';
            let gameBoard = ['', '', '', '', '', '', '', '', ''];
            let gameActive = true;

            function createCell(index) {
                const cell = document.createElement('div');
                cell.classList.add('cell');
                cell.dataset.index = index;
                cell.addEventListener('click', () => handleCellClick(index));
                return cell;
            }

            function handleCellClick(index) {
                if (!gameActive || gameBoard[index] !== '') return;

                gameBoard[index] = currentPlayer;
                cells[index].textContent = currentPlayer;

                if (checkWinner()) {
                    showResult(`${currentPlayer} wins!`);
                } else if (gameBoard.every(cell => cell !== '')) {
                    showResult('It\'s a draw!');
                } else {
                    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
                }
            }

            function checkWinner() {
                const winPatterns = [
                    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
                    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
                    [0, 4, 8], [2, 4, 6]             // Diagonals
                ];

                return winPatterns.some(pattern =>
                    pattern.every(index => gameBoard[index] === currentPlayer)
                );
            }

            function showResult(message) {
                const resultScreen = document.getElementById('result-screen');
                const resultMessage = document.getElementById('result-message');

                resultMessage.textContent = message;
                resultScreen.style.display = 'flex';
                gameActive = false;
            }

            window.resetGame = function () {
                const resultScreen = document.getElementById('result-screen');
                resultScreen.style.display = 'none';
                gameBoard = ['', '', '', '', '', '', '', '', ''];
                cells.forEach(cell => cell.textContent = '');
                currentPlayer = 'X';
                gameActive = true;
            };
        });